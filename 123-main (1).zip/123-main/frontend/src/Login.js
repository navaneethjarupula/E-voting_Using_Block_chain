import React, { useState } from 'react';
import axios from 'axios';
import image from './aadhaar.png';
import './login.css';

const Login = ({ onLogin }) => {
    const [aadhar, setAadhar] = useState('');

    const login = async () => {
        try {
            const response = await axios.post('http://localhost:3001/login', { aadhar });
            const { has_voted } = response.data;
            onLogin(aadhar, has_voted);
        } catch (error) {
            alert('Login failed');
        }
    };

    return (
        <div className='a'>
        <img src={image} className='logo'/> 
        <div>
            <h2 >Login</h2>
            <input
                type="text"
                placeholder="Aadhar Number"
                value={aadhar}
                onChange={(e) => setAadhar(e.target.value)}
            />
            <button onClick={login}>Login</button>
        </div>
        </div>
    );
};

export default Login;
